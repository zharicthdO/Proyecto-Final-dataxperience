"""
generar_datos.py
-----------------
Genero un dataset simulado de telemetria de bateria: numero de ciclos de carga
vs. porcentaje de salud restante (State of Health, SoH), pensado para un
proyecto de mantenimiento predictivo de baterias de robots/drones.

Por que simulado y no una bateria real:
No cuento con un banco de pruebas para descargar/cargar cientos de ciclos de
una bateria real y registrar su degradacion. Para poder desarrollar el
pipeline completo de ciencia de datos, genero datos sinteticos con un modelo
simplificado en vez de usar numeros arbitrarios.

Modelo usado (simplificado):
La salud de una bateria de Litio disminuye de forma aproximadamente lineal
con el numero de ciclos de carga, dentro del rango de vida util tipico:
    SoH(ciclos) = 100 - a*ciclos + ruido   (limitado entre 0 y 100%)

Ademas, inyecto un grupo de "eventos de descarga profunda": ciclos en los que
la bateria fue descargada por debajo de un umbral seguro (una mala practica
de uso), lo cual acelera el desgaste mas alla de lo esperado por el numero de
ciclos. Estos quedan marcados en la columna `evento`, para poder
identificarlos de forma honesta en el analisis (no solo mencionarlos).
"""

import numpy as np
import pandas as pd

SEED = 23
N_NORMAL = 235
N_EVENTO = 25
CICLOS_MAX = 600
A_DEGRADACION = 0.055  # % de salud perdida por ciclo, en uso normal
RUIDO_STD = 2.5        # % de variacion (medicion / diferencias entre celdas)


def generar_dataset(seed: int = SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    # --- Ciclos con uso normal ---
    ciclos_normal = rng.uniform(0, CICLOS_MAX, N_NORMAL)
    ruido = rng.normal(0, RUIDO_STD, N_NORMAL)
    soh_normal = np.clip(100 - A_DEGRADACION * ciclos_normal + ruido, 0, 100)

    # --- Ciclos con descarga profunda (desgaste acelerado) ---
    ciclos_evento = rng.uniform(60, 550, N_EVENTO)
    degradacion_extra = rng.uniform(10, 18, N_EVENTO)
    soh_evento = np.clip(
        100 - A_DEGRADACION * ciclos_evento - degradacion_extra
        + rng.normal(0, RUIDO_STD, N_EVENTO), 0, 100
    )

    ciclos = np.concatenate([ciclos_normal, ciclos_evento])
    soh = np.concatenate([soh_normal, soh_evento])
    evento = np.array(["normal"] * N_NORMAL + ["descarga_profunda"] * N_EVENTO)

    df = pd.DataFrame({
        "Ciclos_Carga": ciclos,
        "Salud_Bateria_%": soh,
        "evento": evento,
    })

    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)
    df["Ciclos_Carga"] = df["Ciclos_Carga"].round(1)
    df["Salud_Bateria_%"] = df["Salud_Bateria_%"].round(2)
    return df


if __name__ == "__main__":
    df = generar_dataset()
    df.to_csv("battery_health_data.csv", index=False)
    print(f"Dataset generado: {len(df)} registros -> battery_health_data.csv")
    print(df[["Ciclos_Carga", "Salud_Bateria_%"]].describe())
